<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","Programador","programador","phonegap") or die ("could not connect database");
?>
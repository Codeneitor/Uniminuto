<?php
include "conexion.php";
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$q=mysqli_query($con,"delete from monedas where id = $id;");
	if($q)
		echo "success";
	else
		echo "error";
	
}
?>
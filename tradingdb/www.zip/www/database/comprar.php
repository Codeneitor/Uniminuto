<?php
include "conexion.php";
if(isset($_POST['comprar'])){
	$div1=$_POST['div1'];
	$desc1=$_POST['desc1'];
	$val1=$_POST['val1'];
	$div2=$_POST['div2'];
	$desc2=$_POST['desc2'];
	$val2=$_POST['val2'];
	$fecha=$_POST['fecha'];
	$consulta=mysqli_query($con,"INSERT INTO monedas(div1, desc1, val1, div2, desc2, val2, fecha)
		VALUES('$div1', '$desc1', '$val1', '$div2', '$desc2', '$val2', '$fecha');");
	if($consulta){
		echo "success";
	} else {
		echo "error";
	}
}
?>
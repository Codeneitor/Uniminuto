<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","Programador","programador","divisas") or die ("could not connect database");
?>
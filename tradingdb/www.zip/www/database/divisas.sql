
CREATE DATABASE divisas;

USE divisas;

DROP TABLE monedas;

CREATE TABLE monedas(
	id INT(11) NOT NULL AUTO_INCREMENT,
	div1 VARCHAR(3) NOT NULL,
	desc1 VARCHAR(50) NOT NULL,
	val1 FLOAT NOT NULL,
	div2 VARCHAR(3) NOT NULL,
	desc2 VARCHAR(50) NOT NULL,
	val2 FLOAT NOT NULL,
	fecha DATE NOT NULL,
	PRIMARY KEY(id)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;

SHOW TABLES;

DESC monedas;

DELETE FROM monedas;

ALTER TABLE monedas AUTO_INCREMENT =1;

INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('COP','Pesos Colombianos',1,'EUR','Euro',0.000295234254,NOW());
INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('COP','Pesos Colombianos',1,'JPY','Yen Japonés',0.0389382472,NOW());
INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('COP','Pesos Colombianos',1,'USD','Dólar Estadounidense',0.000355,NOW());

INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('EUR','Euro',1,'COP','Pesos Colombianos',3387.14085,NOW());
INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('EUR','Euro',1,'JPY','Yen Japonés',131.889328,NOW());
INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('EUR','Euro',1,'USD','Dólar Estadounidense',1.202435,NOW());

INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('JPY','Yen Japonés',1,'COP','Pesos Colombianos',25.6816901,NOW());
INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('JPY','Yen Japonés',1,'EUR','Euro',0.00758211463,NOW());
INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('JPY','Yen Japonés',1,'USD','Dólar Estadounidense',0.009117,NOW());

INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('USD','Dólar Estadounidense',1,'COP','Pesos Colombianos',2816.90141,NOW());
INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('USD','Dólar Estadounidense',1,'EUR','Euro',0.831645785,NOW());
INSERT INTO monedas (div1, desc1, val1, div2, desc2, val2, fecha) VALUES('USD','Dólar Estadounidense',1,'JPY','Yen Japonés',109.685203,NOW());

SELECT * FROM monedas;

$(document).ready(function(){
    $("#guardar").click(function(){
        var div1=$("#div1").val();
        var desc1=$("#desc1").val();
        var val1=$("#val1").val();
        var div2=$("#div2").val();
        var desc2=$("#desc2").val();
        var val2=$("#val2").val();
        var fecha = new Date();
        var dd = fecha.getDate();
        var mm = fecha.getMonth()+1;
        var yyyy = fecha.getFullYear();
        if(dd<10) {
            dd='0'+dd;
        }
        if(mm<10) {
            mm='0'+mm;
        }
        fecha = yyyy+'-'+mm+'-'+dd;
        var dataString="div1="+div1+"&desc1="+desc1+"&val1="+val1+"&div2="+div2+"&desc2="+desc2+"&val2="+val2+"&fecha="+fecha+"&guardar=";
        if($.trim(div1).length>0 & $.trim(desc1).length>0 & $.trim(val1).length>0){
            $.ajax({
                type: "POST",
                url:"http://127.0.0.1/phonegap/tradingdb/guardar.php",
                data: dataString,
                crossDomain: true,
                cache: false,
                beforeSend: function(){
                    $("#guardar").val('Connecting...');
                },
                success: function(data){
                    if(data=="success"){
                        alert("Guardado");
                        $("#guardar").val('Guardar');
                        //location.href='index.html';
                    }else if(data=="error"){
                        alert("error");
                    }
                }
            });
        }return false;
    });
});
$(document).ready(function(){
	var url="http://127.0.0.1/phonegap/tradingdb/read.php";
	$.getJSON(url,function(result){
		console.log(result);
		$.each(result, function(i, field){
			var id=field.id;
			var div1=field.div1;
			var desc1=field.desc1;
			var val1=field.val1;
			var div2=field.div2;
			var desc2=field.desc2;
			var val2=field.val2;
			var fecha=field.fecha;
			$("#listview").append("<div class='col-md-4'><div class='well'><h3>"+desc1+" a "+desc2+"</h3><a href='comprar.html?id="+id+"&div1="+div1+"&desc1="+desc1+"&val1="+val1+"&div2="+div2+"&desc2="+desc2+"&val2="+val2+"'><i class='fa fa-money'></i><br><i> Compra "+val2+" "+desc2+"s con <br>"+val1+" "+desc1+"</i></a><h3>"+div1+" = $ "+val1+"</h3><h3>"+div2+" = $ "+val2+"</h3><p>Invierte en el mundo de las divisas, aprende de este negocio e inicia una nueva carrera.</p></div></div>");
		});
	});
});
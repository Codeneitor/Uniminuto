document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady(){
    console.log('Device Ready...');
}
document.getElementById("cop").onkeyup = function() {calcCOP()};
document.getElementById("usd").onkeyup = function() {calcUSD()};
document.getElementById("eur").onkeyup = function() {calcEUR()};
document.getElementById("jpy").onkeyup = function() {calcJPY()};

function calcCOP() {
    var cop = document.getElementById("cop").value;
    var usd = cop * 0.000365;
    var eur = cop* 0.000295064183;
    var jpy = cop* 0.0391253082;
    document.getElementById("usd").value = usd;
    document.getElementById("eur").value = eur;
    document.getElementById("jpy").value = jpy;
}

function calcUSD() {
    var usd = document.getElementById("usd").value;
    var cop = usd* 2739.72603;
    var eur = usd* 0.808395021;
    var jpy = usd* 107.192625;
    document.getElementById("cop").value = cop;
    document.getElementById("eur").value = eur;
    document.getElementById("jpy").value = jpy;
}

function calcEUR() {
    var eur = document.getElementById("eur").value;
    var cop = eur* 3389.09315;
    var usd = eur* 1.237019;
    var jpy = eur* 132.599314;
    document.getElementById("cop").value = cop;
    document.getElementById("usd").value = usd;
    document.getElementById("jpy").value = jpy;
}

function calcJPY() {
    var jpy = document.getElementById("jpy").value;
    var cop = jpy* 25.5589041;
    var usd = jpy* 0.009329;
    var eur = jpy* 0.00754151715;
    document.getElementById("cop").value = cop;
    document.getElementById("usd").value = usd;
    document.getElementById("eur").value = eur;
}